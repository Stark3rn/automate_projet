#ifndef DEFAULT_AUTOMATE_H
#define DEFAULT_AUTOMATE_H

#include "action_types.h"

void default_exec(AFD *afd);

#endif