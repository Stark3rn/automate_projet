#ifndef ACTION_EXECUTOR_H
#define ACTION_EXECUTOR_H

#include "action_types.h"

void execute_action(Action action);

#endif